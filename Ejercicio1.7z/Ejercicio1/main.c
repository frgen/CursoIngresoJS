#include <stdio.h>
#include <stdlib.h>

// pedir numeros  hasta que el usuario quiera, mostar
//1-Suma de los negativos.
//2-Suma de los positivos.
//3-Cantidad de positivos.
//4-Cantidad de negativos.
//5-Cantidad de ceros.
//6-Cantidad de n�meros pares.
//7-Promedio de positivos.
//8-Promedios de negativos.
//9-Diferencia entre positivos y negativos, (positvos-negativos).

int main()
{
    int numero;
    char respuesta;
    int negativos=0;
    int positivos=0;
    int contPositivos=0;
    int contNegativos=0;
    int contCeros=0;
    int pares=0;
    int maximo;
    int minimo;
    int flag=0;
    float promPositivos;
    float promNegativos;
    int diferencia;

    do
    {
        printf("Ingrese un numero: ");
        scanf("%d", &numero);

        if(numero > 0)
        {
            positivos+=numero;
            contPositivos++;
        }
        else if(numero < 0)
        {
            negativos+=numero;
            contNegativos++;
        }
        else
        {
            contCeros++;
        }

        if(numero % 2 == 0)
        {
            pares++;
        }

        if(flag == 0 || numero>maximo)
        {
            maximo = numero;
            flag = 1;
        }

        printf("Desea ingresar otro numero? s/n ");
        setbuf(stdin, NULL);
        scanf("%c", &respuesta);

    }
    while(respuesta=='s');

    promPositivos = (float)positivos/contPositivos;
    promNegativos = (float)negativos/contNegativos;
    diferencia = positivos-negativos;


    printf("La suma de los positivos: %d", positivos);
    printf("\nLa suma de los negativos: %d", negativos);
    printf("\nCantidad de positivos: %d", contPositivos);
    printf("\nCantidad de negativos: %d", contNegativos);
    printf("\nCantidad de ceros: %d", contCeros);
    printf("\nCantidad de pares: %d", pares);
    printf("\nEl promedio de los positivos: %.2f", promPositivos);
    printf("\nEl promedio de los negativos: %.2f", promNegativos);
    printf("\nLa diferencia entre positivos y negativos es: %d", diferencia);


    return 0;
}
