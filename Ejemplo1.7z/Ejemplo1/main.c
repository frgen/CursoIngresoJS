#include <stdio.h>
#include <stdlib.h>

int main() // Punto de entrada
{
    int unNumero;
    float otroNumero;
    char unCaracter;

    // printf("%d--%p\n", unNumero, &unNumero);

    // printf("Los numeros son: %d y %.2f", unNumero, otroNumero);
    // printf("\nEl caracter es %c", unCaracter);

    printf("Ingrese un numero: ");
    scanf("%d", &unNumero);
    printf("\nEl numero que ingreso es: %d", unNumero);

    printf("\nIngrese un numero flotante: ");
    scanf("%f", &otroNumero);
    printf("\nEl otro es: %f", otroNumero);

    printf("\nIngrese un caracter: %c", unCaracter);
    setbuf(stdin, NULL);
    scanf("%c", &unCaracter);
    printf("\nEl caracter es: %c", unCaracter);

    return 0;
}
